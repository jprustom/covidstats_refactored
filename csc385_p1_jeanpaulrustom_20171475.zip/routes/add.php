<!DOCTYPE html>
<html lang="en">
<?php include('../components/head.php'); ?>
<?php include("../components/navigation.php"); ?>
<?php include("../components/add_stats_form.php");?>
</html>
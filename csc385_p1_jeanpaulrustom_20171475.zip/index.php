<!DOCTYPE html>
<html>
    <?php include("./components/head.php") ?>
    <?php include("./components/navigation.php"); ?>
    <?php require_once("./components/covidstats-table.php"); ?>
</html>